#
#
#New Canonical sim 
#
#
library(mvtnorm)
library("matrixStats")



#These are the quadrature functions

hermite <- function (points, z) {
  p1 <- 1/pi^0.4
  p2 <- 0
  for (j in 1:points) {
    p3 <- p2
    p2 <- p1
    p1 <- z * sqrt(2/j) * p2 - sqrt((j - 1)/j) * p3
  }
  pp <- sqrt(2 * points) * p2
  c(p1, pp)
}

gauss.hermite <- function (points, iterlim = 50) {
  x <- w <- rep(0, points)
  m <- (points + 1)/2
  for (i in 1:m) {
    z <- if (i == 1) 
      sqrt(2 * points + 1) - 2 * (2 * points + 1)^(-1/6)
    else if (i == 2) 
      z - sqrt(points)/z
    else if (i == 3 || i == 4) 
      1.9 * z - 0.9 * x[i - 2]
    else 2 * z - x[i - 2]
    for (j in 1:iterlim) {
      z1 <- z
      p <- hermite(points, z)
      z <- z1 - p[1]/p[2]
      if (abs(z - z1) <= 1e-15) 
        break
    }
    if (j == iterlim) 
      warning("iteration limit exceeded")
    x[points + 1 - i] <- -(x[i] <- z)
    w[i] <- w[points + 1 - i] <- 2/p[2]^2
  }
  r <- cbind(x * sqrt(2), w/sum(w))
  colnames(r) <- c("Points", "Weights")
  r
}
mgauss.hermite <- function(n, mu, sigma, prune=NULL) {
  if(!all(dim(sigma) == length(mu)))
    stop("mu and sigma have nonconformable dimensions")
  
  dm  <- length(mu)
  gh  <- gauss.hermite(n)
  #idx grows exponentially in n and dm
  idx <- as.matrix(expand.grid(rep(list(1:n),dm)))
  pts <- matrix(gh[idx,1],nrow(idx),dm)
  wts <- apply(matrix(gh[idx,2],nrow(idx),dm), 1, prod)
  
  ## prune
  if(!is.null(prune)) {
    qwt <- quantile(wts, probs=prune)
    pts <- pts[wts > qwt,]
    wts <- wts[wts > qwt]
  }
  
  ## rotate, scale, translate points
  eig <- eigen(sigma) 
  rot <- eig$vectors %*% diag(sqrt(eig$values))
  pts <- t(rot %*% t(pts) + mu)
  return(list(points=pts, weights=wts))
}




sig<-c(.5, .25)
rho<-.25
px<-.5
tstart<- -200
tend<- -50
beta<-c(2.3,.26, .14)
tau<-c(0,-.25, -1, -.25)
gam<-c(-1,2, -.05, .5, .25)
alpha<-c(.25,.25)


dgen<-function(M){
	sigma<-matrix(c(sig[1]**2, rho*(sig[1]*sig[2]),rho*(sig[1]*sig[2]), sig[2]**2 ) ,ncol=2, nrow=2)
	b<-rmvnorm(M, c(0,0), sigma)
	t<-runif(M, 0, 85)
	tcontx<-	rbinom(M, 1, .5)

#First
	y_1<-rbinom(M,	1,	.5)
	#				int.		y-1		x		re
	g1<-rgamma(M,shape=(exp(beta[1]+beta[2]*y_1+ tcontx*beta[3]+ b[,2]) ), scale= 1)
	#					int.		y-1		gap		x		parity
	y1<-rbinom(M,	1,	plogis(gam[1]+gam[2]*y_1 + gam[3]*g1 + tcontx*gam[4]+ gam[5]*1+ b[,1]))
	#
	t1<-t
	t2<-	t-g1
	#
	c1<-(t2<=0)*1

#Second
	#				int.		y-1		x		re
	g2<-rgamma(M,shape=(exp(beta[1]+beta[2]*y1+ tcontx*beta[3]+ b[,2]) ), scale= 1)
	#					int.		y-1		gap		x		parity
	y2<-rbinom(M,	1,	plogis(gam[1]+gam[2]*y1 + gam[3]*g2 + tcontx*gam[4]+ gam[5]*2+ b[,1]))
	#
	t3<-	(t2-g2)
	#							re portion			int. 		parity	x		y-1

 c2<-	(c1==0)*((2*c1+((t3<=0)*1)+rbinom(M,1,1-plogis((b[,1]*alpha[1]+b[,2]*alpha[2])+tau[1]+tau[2]*2 + tcontx*tau[3]+y1*tau[4])))>=1)*1 +
	(c1==1)*(2*c1+((t3<=0)*1)+rbinom(M,1,1-plogis((b[,1]*alpha[1]+b[,2]*alpha[2])+tau[1]+tau[2]*2 + tcontx*tau[3]+y1*tau[4])))

#Third
	#				int.		y-1		x		re
	g3<-rgamma(M,shape=(exp(beta[1]+beta[2]*y2+ tcontx*beta[3]+ b[,2]) ), scale= 1)
	#					int.		y-1		gap		x		parity
	y3<-rbinom(M,	1,	plogis(gam[1]+gam[2]*y2 + gam[3]*g3 + tcontx*gam[4]+ gam[5]*3+ b[,1]))
	#
	t4<-	(t3-g3)
	#							re portion			int. 		parity	x		y-1
	c3<-2*c2+((t4<=0)*1)+rbinom(M,1,1-plogis((b[,1]*alpha[1]+b[,2]*alpha[2])+tau[1]+tau[2]*3 + tcontx*tau[3]+y2*tau[4]))

#Fourth 
	#				int.		y-1		x		re
	g4<-rgamma(M,shape=(exp(beta[1]+beta[2]*y3+ tcontx*beta[3]+ b[,2]) ), scale= 1)
	#					int.		y-1		gap		x		parity
	y4<-rbinom(M,	1,	plogis(gam[1]+gam[2]*y3 + gam[3]*g4 + tcontx*gam[4]+ gam[5]*4+ b[,1]))
	#
	t5<-	(t4-g4)
	#							re portion			int. 		parity	x		y-1
	c4<-2*c3+((t5<=0)*1)+rbinom(M,1,1-plogis((b[,1]*alpha[1]+b[,2]*alpha[2])+tau[1]+tau[2]*4 + tcontx*tau[3]+y3*tau[4]))


#Fifth 
	#				int.		y-1		x		re
	g5<-rgamma(M,shape=(exp(beta[1]+beta[2]*y4+ tcontx*beta[3]+ b[,2]) ), scale= 1)
	#					int.		y-1		gap		x		parity
	y5<-rbinom(M,	1,	plogis(gam[1]+gam[2]*y4 + gam[3]*g5 + tcontx*gam[4]+ gam[5]*5+ b[,1]))
	#
	t6<-	(t5-g5)
	#							re portion			int. 		parity	x		y-1
	c5<-2*c4+1


D<- matrix(0, ncol=8, nrow=M*5)
j<-1
for (i in 1:M){ 
	D[j:(j+4),]<-cbind(i, 1:5, c(y_1[i], y1[i],y2[i],y3[i],y4[i]), 
	c( y1[i],y2[i],y3[i],y4[i],y5[i]), 
	c(g1[i],g2[i],g3[i],g4[i],g5[i]), 
	c(t1[i],t2[i],t3[i],t4[i],t5[i]), 
	c(c1[i],c2[i],c3[i],c4[i],c5[i]), 
	 tcontx[i])
	j<-j+5
}

D<-D[which(D[,7]<2),]
D<-D[-which(D[,7]==1 & D[,2]==1), ]
D
}


size<-c(25000, 10000, 2500)
#size<-1000
#size<-25000
#482<-1
#rep<-size


for ( rep in size) {
	set.seed(482)


	sig<-c(.5, .25)
	rho<-.25
	px<-.5
	beta<-c(2.3,.26, .14)
	tau<-c(0,-.25, -1, -.25)
	gam<-c(-1,2, -.05, .5, .25)
	alpha<-c(.25,.25)

	d<-dgen(rep)


completep<-length(unique(d[,1]))/25000

	idinds<-lapply(unique(d[,1]), FUN= l<-function(i) which(d[,1]==i))
	
	npoints<-11
	
	sig<-c(log(.5)*10, log(.25)*10)
	rho<-qlogis((.25/2)+.5)
	tau<-c(0,-.25, -1, -.25)
	gam<-c(-1,2, -.05, .5, .25)
	alpha<-c(.25,.25)
	beta<-c(2.3,.26, .14)
	
	par<-c(sig, rho, tau,  gam,  alpha, beta)
	
	
	l<-function(par){
		beta<-par[15:17]
		alpha<-par[13:14]
		gam<-par[8:12]
		tau<-par[4:7]
	
	#	sigma<-matrix(c(exp(par[1]/10)**2, ((plogis(par[3])-.5)*2)*(exp(par[1]/10)*exp(par[2]/10)),
	#	((plogis(par[3])-.5)*2)*(exp(par[1]/10)*exp(par[2]/10)), exp(par[2]/10)**2 ) ,ncol=2, nrow=2)
	
	sigma<-matrix((plogis(par[3])-.5)*2, ncol=2, nrow=2)
	diag(sigma)<-1
	
			mghp<-mgauss.hermite(npoints, c(0,0), sigma, prune=NULL)
	
			b1<-mghp$points[,1]*(exp((par[1]/10)))*sqrt(2)
			b2<-mghp$points[,2]*(exp((par[2]/10)))*sqrt(2)
	
	
	#		b1<-mghp$points[,1]
	#		b2<-mghp$points[,2]
			w<-mghp$weights	
	
	#a1<-a2<-0 head(d)
		gapcon<-function(a1, a2){
			p<-(plogis((tau[1]+tau[2]*(d[,2]) +tau[3]*d[,8]+tau[4]*d[,3])+(a1*alpha[1]+a2*alpha[2])))
			p[which(d[,2]==1)]<-1
			p[which(d[,2]==5)]<-0
	
			(
			(
			(plogis((gam[1]+gam[2]*d[,3]+gam[3]*d[,5]+gam[4]*d[,8]+gam[5]*(d[,2]))+a1)*d[,4])+
			((1-plogis((gam[1]+gam[2]*d[,3]+gam[3]*d[,5]+gam[4]*d[,8]+gam[5]*(d[,2]))+a1)))*
			(1-d[,4])
			)
			)*
	#gap and continuation portion tail(d) exp(-1.6939)
			(
			(p*dgamma(d[,5],shape=exp(beta[1]+beta[2]*d[,3]+beta[3]*d[,8]+a2), scale= 1)*(1-d[,7])
			)
			)+ 
			((p*(1-pgamma(d[,6],shape=exp(beta[1]+beta[2]*d[,3]+beta[3]*d[,8]+a2), scale= 1))+(1-p))*d[,7])
		}
	
	
	
	qpnts<-cbind(b1, b2)
	
	stuff<-matrix(unlist(lapply(1:nrow(qpnts), FUN= raw<- function(i) (gapcon(qpnts[i,1], qpnts[i,2]))   )), ncol=nrow(d), byrow=T)
	
	stuff2<-matrix(0, ncol=length(idinds), nrow=npoints**2)
		for (i in 1:length(idinds)) { 
		stuff2[,i]<- rowProds(cbind(rep(1,npoints**2),stuff[, unlist(idinds[i])]))
	}		
			stuff2<-matrix(0, ncol=length(idinds), nrow=npoints**2)
	
			for (i in 1:length(idinds)) { 
				stuff2[,i]<- rowProds(cbind(rep(1,npoints**2),stuff[, unlist(idinds[i])]))
			}	
	
				ll<-sum(-log(rowSums(t(stuff2)%*% diag(w))))
	ll
	}
	
	
	
	
	
	
	
	npoints<-10
	
l(par)	
	
	dumb<-optim(par, l,method="BFGS", control=c(maxit=500, trace=T)  , hessian=T)



name<-paste("a_", rep,"_", 482, sep="")

save(dumb, file=name)

namemiss<-paste("miss_", rep,"_", 482, sep="")
save(completep, file=namemiss)


}




#END!!!!!!!!!!			